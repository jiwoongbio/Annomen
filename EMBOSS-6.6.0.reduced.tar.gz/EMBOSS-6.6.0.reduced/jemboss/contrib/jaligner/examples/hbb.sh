java -classpath ../jaligner.jar:../matrices.jar gnu.bioinformatics.jaligner.SW hbb-horse.fasta hbb-human.fasta
